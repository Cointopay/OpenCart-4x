<?php
// Text
$_['text_title'] = 'Cointopay International B.V.';
$_['text_crypto_coin_lable'] = 'Choose Payment Currency :';