<?php
// Text
$_['text_title'] = 'Payment details';

$_['text_checkout_number'] = 'Checkout# ';
$_['text_transaction_id'] = 'Transaction ID ';

$_['text_address'] = 'Payment Address ';
$_['text_amount'] = 'Amount ';
$_['text_expiry'] = 'Expiry ';
$_['text_coinname'] = 'Cointype ';
$_['text_pay_with_other'] = 'For more payment details';
$_['text_clickhere'] = 'Click here';

$_['text_success'] = 'Thank you, your payment is received!';
$_['text_expired'] = 'Sorry, payment time expired!';
$_['text_failed'] = 'Sorry, your payment has failed';
$_['text_cancel'] = 'Sorry, your payment has cancelled';
$_['text_waiting'] = 'Sorry, your payment is in waiting';
$_['text_notenough'] = 'Payment not enough for order #';
$_['text_invoice_link'] = '. Please contact support ';
$_['text_ctptag'] = 'Memo/Tag:';
$_['text_crypto_link'] = 'CRYPTO LINK';
$_['text_coinadres_link'] = 'CRYPTO ADDRESS';